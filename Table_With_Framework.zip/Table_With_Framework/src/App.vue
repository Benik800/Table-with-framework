<template>
  <div class="container">
    <StudentForm @add-student="addStudent" />
    <StudentTable :students="paginatedStudents" @delete-student="deleteStudent" />
    <PaginationControls
      :total="students.length"
      :current-page.sync="currentPage"
      :page-size.sync="pageSize"
    />
  </div>
</template>

<script>
import StudentForm from './components/StudentForm.vue';
import StudentTable from './components/StudentTable.vue';
import PaginationControls from './components/PaginationControls.vue';

export default {
  components: {
    StudentForm,
    StudentTable,
    PaginationControls,
  },
  data() {
    return {
      students: JSON.parse(localStorage.getItem('students')) || [],
      currentPage: 1,
      pageSize: 5,
    };
  },
  computed: {
    paginatedStudents() {
      const startIndex = (this.currentPage - 1) * this.pageSize;
      return this.students.slice(startIndex, startIndex + this.pageSize);
    },
  },
  methods: {
    addStudent(student) {
      this.students.push(student);
      this.saveToLocalStorage();
      this.currentPage = Math.ceil(this.students.length / this.pageSize); // Переход к последней странице
    },
    deleteStudent(index) {
      this.students.splice((this.currentPage - 1) * this.pageSize + index, 1);
      this.saveToLocalStorage();
    },
    saveToLocalStorage() {
      localStorage.setItem('students', JSON.stringify(this.students));
    },
  },
};
</script>

<style src="./assets/styles/index.css"></style>