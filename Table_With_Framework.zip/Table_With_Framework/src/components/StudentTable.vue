<template>
    <table class="table table-bordered studentsTable mb-4">
      <thead class="table-light">
        <tr>
          <th>Фамилия</th>
          <th>Имя</th>
          <th>Отчество</th>
          <th>Дата рождения</th>
          <th>Группа</th>
          <th>Средний балл</th>
          <th>Удалить</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(student, index) in students" :key="index">
          <td>{{ student.lastName }}</td>
          <td>{{ student.firstName }}</td>
          <td>{{ student.middleName }}</td>
          <td>{{ formatDate(student.dateOfBirth) }}</td>
          <td>{{ student.group }}</td>
          <td>{{ student.averageScore }}</td>
          <td>
            <button class="btn btn-danger" @click="deleteStudent(index)">Удалить</button>
          </td>
        </tr>
      </tbody>
    </table>
  </template>
  
  <script>
  export default {
    props: {
      students: {
        type: Array,
        required: true,
      },
    },
    methods: {
      deleteStudent(index) {
        this.$emit('delete-student', index);
      },
      formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU'); // Форматируем дату
      },
    },
  };
  </script>