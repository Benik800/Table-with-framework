<template>
    <div class="addStudent mb-4">
      <h2>Форма добавления студента</h2>
      <form @submit.prevent="onSubmit">
        <div class="addStudent__form-container">
          <div class="addStudent__form__block" v-for="(value, key) in newStudent" :key="key">
            <label :for="key" class="addStudent__form__label">{{ formatLabel(key) }}</label>
            <input v-model="newStudent[key]" :type="key === 'dateOfBirth' ? 'date' : 'text'" class="addStudent__form__input" :placeholder="'Введите ' + formatLabel(key)" required>
          </div>
          <button class="addStudent__form__button" type="submit">Добавить студента</button>
        </div>
      </form>
    </div>
  </template>
  
  <script>
export default {
  data() {
    return {
      newStudent: {
        lastName: '',
        firstName: '',
        middleName: '',
        dateOfBirth: '',
        group: '',
        averageScore: null,
      },
      labels: {
        lastName: 'Фамилия',
        firstName: 'Имя',
        middleName: 'Отчество',
        dateOfBirth: 'Дата рождения',
        group: 'Группа',
        averageScore: 'Средний балл',
      },
    };
  },
  methods: {
    onSubmit() {
      const student = { ...this.newStudent };
      this.$emit('add-student', student);
      this.resetForm();
    },
    resetForm() {
      this.newStudent = {
        lastName: '',
        firstName: '',
        middleName: '',
        dateOfBirth: '',
        group: '',
        averageScore: null,
      };
    },
    formatLabel(key) {
      return this.labels[key] || key;
    },
  },
};
</script>